import streamlit as st
from auth import (
    save_user, verify_login, username_exists, email_exists, get_user_info,
    validate_name, validate_email, validate_username, validate_password
)

# ── Injected CSS ─────────────────────────────────────────────────────────────

AUTH_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

/* ── Root Theme ── */
[data-testid="stAppViewContainer"] {
    background: #0a0a0f;
}
[data-testid="stHeader"] { background: transparent; }
[data-testid="stSidebar"] { display: none; }

/* ── Auth wrapper ── */
.auth-shell {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 90vh;
    padding: 2rem 1rem;
}
.auth-card {
    background: linear-gradient(145deg, #12121c 0%, #1a1a2e 100%);
    border: 1px solid #2a2a45;
    border-radius: 20px;
    padding: 2.8rem 2.5rem;
    width: 100%;
    max-width: 460px;
    box-shadow: 0 25px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.03);
    position: relative;
    overflow: hidden;
}
.auth-card::before {
    content: "";
    position: absolute;
    top: -60px; right: -60px;
    width: 180px; height: 180px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(99,102,241,0.18) 0%, transparent 70%);
    pointer-events: none;
}
.auth-card::after {
    content: "";
    position: absolute;
    bottom: -40px; left: -40px;
    width: 140px; height: 140px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(236,72,153,0.12) 0%, transparent 70%);
    pointer-events: none;
}

/* ── Brand ── */
.brand-row {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 0.3rem;
}
.brand-icon {
    width: 38px; height: 38px;
    background: linear-gradient(135deg, #6366f1, #ec4899);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.2rem;
}
.brand-name {
    font-family: 'Syne', sans-serif;
    font-size: 1.5rem;
    font-weight: 800;
    color: #fff;
    letter-spacing: -0.5px;
}
.brand-name span { color: #6366f1; }

.auth-headline {
    font-family: 'Syne', sans-serif;
    font-size: 1.7rem;
    font-weight: 700;
    color: #fff;
    margin: 1.2rem 0 0.3rem;
    line-height: 1.2;
}
.auth-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.88rem;
    color: #6b6b8a;
    margin-bottom: 1.6rem;
}

/* ── Tab Pills ── */
.tab-row {
    display: flex;
    background: #0e0e1a;
    border-radius: 12px;
    padding: 4px;
    margin-bottom: 1.6rem;
    gap: 4px;
}
.tab-pill {
    flex: 1;
    text-align: center;
    padding: 8px 0;
    border-radius: 9px;
    font-family: 'DM Sans', sans-serif;
    font-size: 0.88rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    color: #5a5a78;
    border: none;
    background: transparent;
}
.tab-pill.active {
    background: linear-gradient(135deg, #6366f1, #818cf8);
    color: #fff;
    box-shadow: 0 4px 14px rgba(99,102,241,0.35);
}

/* ── Streamlit input overrides ── */
[data-testid="stTextInput"] label,
[data-testid="stTextInput"] p {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.82rem !important;
    color: #8888aa !important;
    font-weight: 500 !important;
    letter-spacing: 0.03em;
    text-transform: uppercase;
}
[data-testid="stTextInput"] input {
    background: #0e0e1a !important;
    border: 1px solid #2a2a45 !important;
    border-radius: 10px !important;
    color: #e8e8f0 !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.95rem !important;
    padding: 0.55rem 0.9rem !important;
    transition: border-color 0.2s !important;
}
[data-testid="stTextInput"] input:focus {
    border-color: #6366f1 !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.15) !important;
}

/* ── Buttons ── */
[data-testid="stButton"] > button {
    width: 100%;
    background: linear-gradient(135deg, #6366f1 0%, #818cf8 100%);
    color: #fff;
    border: none;
    border-radius: 12px;
    padding: 0.65rem 1.2rem;
    font-family: 'Syne', sans-serif;
    font-size: 1rem;
    font-weight: 700;
    letter-spacing: 0.02em;
    cursor: pointer;
    transition: all 0.2s;
    box-shadow: 0 6px 20px rgba(99,102,241,0.3);
    margin-top: 0.4rem;
}
[data-testid="stButton"] > button:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 28px rgba(99,102,241,0.45);
}
[data-testid="stButton"] > button:active {
    transform: translateY(0);
}

/* ── Alerts ── */
[data-testid="stAlert"] {
    border-radius: 10px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.88rem !important;
}

/* ── Divider ── */
.auth-divider {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 1.2rem 0;
    color: #3a3a55;
    font-family: 'DM Sans', sans-serif;
    font-size: 0.78rem;
}
.auth-divider::before, .auth-divider::after {
    content: "";
    flex: 1;
    height: 1px;
    background: #2a2a45;
}

/* ── Column gap fix ── */
[data-testid="column"] { padding: 0 4px !important; }

/* ── Welcome banner ── */
.welcome-banner {
    background: linear-gradient(135deg, #12121c 0%, #1a1a2e 100%);
    border: 1px solid #2a2a45;
    border-radius: 16px;
    padding: 1.6rem 2rem;
    text-align: center;
    margin-bottom: 1.5rem;
}
.welcome-banner h2 {
    font-family: 'Syne', sans-serif;
    color: #fff;
    font-size: 1.4rem;
    margin: 0 0 0.3rem;
}
.welcome-banner p {
    font-family: 'DM Sans', sans-serif;
    color: #8888aa;
    font-size: 0.9rem;
    margin: 0;
}
.avatar-circle {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, #6366f1, #ec4899);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem;
    margin: 0 auto 0.9rem;
    box-shadow: 0 8px 24px rgba(99,102,241,0.4);
}

/* ── Password strength bar ── */
.pw-strength {
    height: 4px;
    border-radius: 4px;
    margin-top: 6px;
    transition: all 0.3s;
}
</style>
"""

# ── Helpers ──────────────────────────────────────────────────────────────────

def _field_error(msg: str):
    st.markdown(f'<p style="color:#f87171;font-size:0.8rem;font-family:\'DM Sans\',sans-serif;margin:2px 0 6px;padding-left:2px">⚠ {msg}</p>', unsafe_allow_html=True)


def _brand():
    st.markdown("""
    <div class="brand-row">
        <div class="brand-icon">🚗</div>
        <div class="brand-name">Uber<span>NCR</span></div>
    </div>
    """, unsafe_allow_html=True)


# ── Main render function ──────────────────────────────────────────────────────

def show_auth_page():
    st.markdown(AUTH_CSS, unsafe_allow_html=True)

    # Centre-column layout
    _, mid, _ = st.columns([1, 2, 1])

    with mid:
        _brand()

        # Tab selector stored in session
        if "auth_tab" not in st.session_state:
            st.session_state.auth_tab = "login"

        col_login, col_signup = st.columns(2)
        with col_login:
            if st.button("🔑  Login", key="tab_login"):
                st.session_state.auth_tab = "login"
        with col_signup:
            if st.button("✨  Sign Up", key="tab_signup"):
                st.session_state.auth_tab = "signup"

        st.markdown("<hr style='border-color:#2a2a45;margin:0.5rem 0 1.2rem'>", unsafe_allow_html=True)

        # ── LOGIN ──────────────────────────────────────────────────────────
        if st.session_state.auth_tab == "login":
            st.markdown('<div class="auth-headline">Welcome back 👋</div>', unsafe_allow_html=True)
            st.markdown('<div class="auth-sub">Sign in to your analytics dashboard</div>', unsafe_allow_html=True)

            username = st.text_input("Username", placeholder="your_username", key="login_user")
            password = st.text_input("Password", placeholder="••••••••", type="password", key="login_pass")

            if st.button("Sign In →", key="login_btn"):
                errors = False

                if not username.strip():
                    _field_error("Username is required.")
                    errors = True
                if not password:
                    _field_error("Password is required.")
                    errors = True

                if not errors:
                    if verify_login(username, password):
                        info = get_user_info(username)
                        st.session_state.logged_in = True
                        st.session_state.current_user = username.strip().lower()
                        st.session_state.user_info = info
                        st.success(f"Welcome back, {info.get('firstname', username)}! 🎉")
                        st.rerun()
                    else:
                        st.error("❌  Invalid username or password. Please try again.")

            st.markdown('<div class="auth-divider">Don\'t have an account?</div>', unsafe_allow_html=True)
            if st.button("Create Account →", key="go_signup"):
                st.session_state.auth_tab = "signup"
                st.rerun()

        # ── SIGN UP ────────────────────────────────────────────────────────
        else:
            st.markdown('<div class="auth-headline">Create account ✨</div>', unsafe_allow_html=True)
            st.markdown('<div class="auth-sub">Join to access the full analytics suite</div>', unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                firstname = st.text_input("First Name", placeholder="Jane", key="su_fn")
            with col2:
                lastname = st.text_input("Last Name", placeholder="Doe", key="su_ln")

            email = st.text_input("Email Address", placeholder="jane@example.com", key="su_email")
            username = st.text_input("Username", placeholder="jane_doe_99", key="su_user")
            password = st.text_input("Password", placeholder="Min 8 chars, upper, lower, digit, symbol", type="password", key="su_pass")
            confirm_pw = st.text_input("Confirm Password", placeholder="Re-enter password", type="password", key="su_confirm")

            if st.button("Create My Account →", key="signup_btn"):
                errors = []

                fn_err = validate_name(firstname)
                ln_err = validate_name(lastname)
                em_err = validate_email(email)
                un_err = validate_username(username)
                pw_err = validate_password(password)

                if fn_err:   errors.append(f"First Name: {fn_err}")
                if ln_err:   errors.append(f"Last Name: {ln_err}")
                if em_err:   errors.append(f"Email: {em_err}")
                if un_err:   errors.append(f"Username: {un_err}")
                if pw_err:   errors.append(f"Password: {pw_err}")
                if password and confirm_pw != password:
                    errors.append("Passwords do not match.")

                # Uniqueness checks (only if format is valid)
                if not em_err and email_exists(email):
                    errors.append("This email is already registered. Please log in.")
                if not un_err and username_exists(username):
                    errors.append("Username is taken. Please choose another.")

                if errors:
                    for e in errors:
                        _field_error(e)
                else:
                    save_user(firstname, lastname, email, username, password)
                    st.success("🎉  Account created! You can now log in.")
                    st.session_state.auth_tab = "login"
                    st.rerun()

            st.markdown('<div class="auth-divider">Already have an account?</div>', unsafe_allow_html=True)
            if st.button("Sign In Instead →", key="go_login"):
                st.session_state.auth_tab = "login"
                st.rerun()


# ── Logout helper (call from sidebar) ────────────────────────────────────────

def show_user_sidebar():
    info = st.session_state.get("user_info", {})
    name = f"{info.get('firstname', '')} {info.get('lastname', '')}".strip() or st.session_state.current_user
    st.sidebar.markdown(f"""
    <div style="padding:12px 0 8px;border-bottom:1px solid #2a2a45;margin-bottom:8px">
        <div style="font-size:1.5rem;text-align:center">👤</div>
        <div style="text-align:center;font-weight:600;color:#e8e8f0;font-size:0.95rem">{name}</div>
        <div style="text-align:center;color:#6b6b8a;font-size:0.78rem">@{st.session_state.current_user}</div>
    </div>
    """, unsafe_allow_html=True)
    if st.sidebar.button("🚪  Logout", use_container_width=True):
        for key in ["logged_in", "current_user", "user_info", "auth_tab"]:
            st.session_state.pop(key, None)
        st.rerun()
