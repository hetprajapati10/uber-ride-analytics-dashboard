import pandas as pd
import os
import hashlib
import re

USERS_FILE = "users.csv"

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def load_users() -> pd.DataFrame:
    if os.path.exists(USERS_FILE):
        return pd.read_csv(USERS_FILE)
    else:
        df = pd.DataFrame(columns=["firstname", "lastname", "email", "username", "password"])
        df.to_csv(USERS_FILE, index=False)
        return df

def save_user(firstname, lastname, email, username, password) -> None:
    df = load_users()
    new_row = pd.DataFrame([{
        "firstname": firstname.strip(),
        "lastname": lastname.strip(),
        "email": email.strip().lower(),
        "username": username.strip().lower(),
        "password": hash_password(password)
    }])
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv(USERS_FILE, index=False)

def username_exists(username: str) -> bool:
    df = load_users()
    return username.strip().lower() in df["username"].str.lower().values

def email_exists(email: str) -> bool:
    df = load_users()
    return email.strip().lower() in df["email"].str.lower().values

def verify_login(username: str, password: str) -> bool:
    df = load_users()
    hashed = hash_password(password)
    match = df[
        (df["username"].str.lower() == username.strip().lower()) &
        (df["password"] == hashed)
    ]
    return len(match) > 0

def get_user_info(username: str) -> dict:
    df = load_users()
    row = df[df["username"].str.lower() == username.strip().lower()]
    if not row.empty:
        return row.iloc[0].to_dict()
    return {}

# ── Validators ──────────────────────────────────────────────────────────────

def validate_name(name: str) -> str | None:
    """Returns error string or None if valid."""
    if not name.strip():
        return "This field cannot be empty."
    if len(name.strip()) < 2:
        return "Must be at least 2 characters."
    if not re.match(r"^[A-Za-z\s\-']+$", name.strip()):
        return "Only letters, spaces, hyphens and apostrophes allowed."
    return None

def validate_email(email: str) -> str | None:
    if not email.strip():
        return "Email cannot be empty."
    pattern = r"^[\w\.\+\-]+@[\w\-]+\.[a-zA-Z]{2,}$"
    if not re.match(pattern, email.strip()):
        return "Enter a valid email address."
    return None

def validate_username(username: str) -> str | None:
    if not username.strip():
        return "Username cannot be empty."
    if len(username.strip()) < 3:
        return "Username must be at least 3 characters."
    if len(username.strip()) > 20:
        return "Username must be at most 20 characters."
    if not re.match(r"^[A-Za-z0-9_]+$", username.strip()):
        return "Username can only contain letters, numbers and underscores."
    return None

def validate_password(password: str) -> str | None:
    if not password:
        return "Password cannot be empty."
    if len(password) < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter."
    if not re.search(r"[a-z]", password):
        return "Password must contain at least one lowercase letter."
    if not re.search(r"\d", password):
        return "Password must contain at least one digit."
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>_\-]", password):
        return "Password must contain at least one special character."
    return None
